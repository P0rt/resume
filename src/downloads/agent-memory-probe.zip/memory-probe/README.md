# A small probe for memory retrieval and use

This is a **handwritten toy fixture**, not a benchmark, a production memory system,
or a replication of InMind. Its twelve developer constraints were selected to make
their consequences easy to inspect. Some indirect tasks deliberately use different
vocabulary from their stored fact. The dataset is not a representative sample.

The executable uses only the Python standard library. It makes no network calls,
reads no API keys, installs nothing, and **does not run or grade a language model**.
Its measured results concern retrieval and context delivery only. A retrieval hit
does not show that an agent understood or used a fact.

## Run

From this directory, with Python 3.9 or later:

```sh
python3 run_probe.py
```

This writes `results.json`, `input-manifest.json`, `behavioral-rubrics.json`, and
72 independent JSON inputs under `inputs/`. Defaults resolve relative to the
script, so invoking it from another working directory also works.

To keep a separate run:

```sh
python3 run_probe.py --top-k 5 --output-dir /tmp/memory-probe-k5
```

`--dataset PATH` accepts the same schema. A repeat run overwrites the same generated
file names; use a fresh output directory for a changed dataset to avoid stale
input files. The script does not delete anything. `--top-k` must be at least 1.

## What is fixed

The initial dataset and retrieval settings were written before the first run.
The included result is the first default run, with no tuning after viewing counts.
Every report contains a SHA-256 of the exact dataset bytes. Changing whitespace
also changes that digest. No randomness or timestamps affect the report.

The base corpus has twelve target facts and twelve distractors. Each case contains
a stored-fact reference, a direct question, an indirect development task, a
behavioral rubric, an unrelated request, and an explicit newer decision that
supersedes all or part of the old constraint. The updated decision applies only
within its stated scope.

The baseline is transparent BM25: lowercase `[a-z0-9]+` tokens, no stemming, no
stopword removal, each query term counted once, `k1=1.5`, `b=0.75`, and default
`top_k=3`. Its IDF is `ln(1 + (N - df + 0.5) / (df + 0.5))`. Record IDs and case
metadata do not participate in scoring. Nonpositive scores are excluded. Results
are sorted by unrounded score descending, then record ID ascending for ties.
Common function words can create matches; that is part of this simple baseline.

## Conditions and outputs

Each case exports six **isolated** inputs. Each JSON file contains an `input_id`
and a `messages` list ready to adapt to an external chat API:

1. `direct`: the direct recall question with its BM25-retrieved context.
2. `implicit`: the development task with its BM25-retrieved context.
3. `explicit`: the same development task with the target fact explicitly provided
   as the only memory. This is a context-delivery control, not a retrieval score.
4. `irrelevant`: an unrelated request with its BM25-retrieved context.
5. `supersession_retrieved`: the development task with BM25 retrieval from the
   base corpus plus that case's newer decision. Both old and new records are
   eligible. The report separately records whether each was returned.
6. `supersession_explicit`: the same task with the old fact and then the explicit
   newer decision delivered together. This supplies both facts so a separate
   evaluator could inspect whether the agent follows the current rule.

The system instruction is identical across all inputs. No expected answer,
reference rubric, score, or target record ID is included in model messages.
Use only the `messages` list as model input; retain `input_id` outside the prompt.
The manifest separately records which facts were delivered. Behavioral rubrics
live in their own file, with null responses and grades because no evaluation ran.

The `explicit` control supplies less distractor context than `implicit`, and the
supersession control supplies different context from retrieval. Even after running
a model, comparisons would mix retrieval availability and context composition;
these are diagnostic conditions, not a causal estimate of retrieval's effect.

## Interpreting the report

`target_fact_retrieved_count` means the known target record appeared in the returned
top-k list. For direct and implicit queries this is a per-case target retrieval hit
count. It is not answer correctness, application success, or an LLM memory score.
For irrelevant queries the same count measures **exposure to a target fact on an
unrelated request**, not whether an agent over-applied it. Other returned records
are not labeled as relevant or irrelevant, so this is not precision or a full
false-positive-rate estimate.

The supersession counts say which decisions reached the context, not which one
an agent obeyed. The explicit delivery counts are true by construction and should
never be presented as measured model recall.

To perform a later behavioral evaluation, run every input in a fresh conversation
with the same model version and settings. Save the exact response separately and
have a reviewer assess it against the withheld rubric. Distinguish at least:

- Was the applicable fact delivered to the agent?
- Did the response satisfy the behavioral constraint?
- Did an unrelated fact change an irrelevant answer?
- Did the response respect an explicitly superseding decision?

Do not feed the rubric to the answering agent. Do not reuse conversation history
between cases or conditions. Disclose model settings, repetitions, grading rules,
and uncertainty before making comparisons. The twelve selected cases alone cannot
support claims about memory systems in general.

**Actual LLM evaluation: not run. No model outputs or application scores are included.**

## Included run

The first run at the fixed default `top_k=3` retrieved the target fact for 12/12
direct questions and 4/12 indirect tasks. An unrelated request exposed its paired
target fact in 1/12 cases. With each case's newer decision added to the corpus,
retrieval returned the old target in 3/12 cases and the newer decision in 11/12.
The old/new counts may overlap and are not behavioral success rates. The indirect
target hits were `tenant`, `assets`, `timezone`, and `compatibility`.

Dataset SHA-256:
`85eff914cf2dc9da353eeb5a7fbc78991842a6d458649c3f607dbd6c0b04567a`.

A separate verification run reproduced the report and all 72 inputs byte for
byte. Checks also independently recounted hits from rankings, verified the dataset
digest, confirmed deterministic tie ordering and exclusion of zero-score matches,
and confirmed that `--help` works and `--top-k 0` is rejected. These checks validate
the small program, not the memory abilities of a language model.
