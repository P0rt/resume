#!/usr/bin/env python3
"""Verify one saved synthetic trace offline; not the full ChartReplay evaluator."""
import copy
import hashlib
import json
from pathlib import Path

DATA_SHA256 = "9a48246d8978fd5645853a179e05c510bb48e1d5f14f8a5b47d156cc38206625"
FILES = {"README.md", "chartreplay-hidden-conflict.json", "verify_trace.py"}
DOCS = ["CR-02-0000-D34123", "CR-02-0000-D12503", "CR-02-0000-D31621",
        "CR-02-0000-D39816", "CR-02-0000-D95387", "CR-02-0000-D24016"]
FIRST, SECOND, CORRECTION = [d + ":1" for d in DOCS[:3]]
FIELDS = set("claim_id event_id patient_id subject kind concept value unit event_time assertion evidence supersedes state".split())


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def strict_json(text):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, "Duplicate JSON member")
            result[key] = value
        return result
    def invalid_constant(value):
        raise ValueError("Non-finite JSON constant")
    return json.loads(text, object_pairs_hook=pairs, parse_constant=invalid_constant)


def claims(chart):
    require(isinstance(chart, dict) and set(chart) == {"claims"}, "Chart schema")
    require(isinstance(chart["claims"], list), "Claims must be a list")
    result = {}
    for original in chart["claims"]:
        require(isinstance(original, dict) and set(original) == FIELDS, "Claim schema")
        row = copy.deepcopy(original)
        for key in FIELDS - {"evidence", "supersedes"}:
            require(isinstance(row[key], str), "Claim field type")
        for key in ("evidence", "supersedes"):
            require(isinstance(row[key], list) and all(isinstance(v, str) for v in row[key]), "Claim list type")
            require(len(row[key]) == len(set(row[key])), "Duplicate claim links")
            row[key] = sorted(row[key])
        require(row["claim_id"] not in result, "Duplicate claim ID")
        result[row["claim_id"]] = row
    return result


def dispositions(accumulated):
    """Case-scoped diagnostic: explicit corrections, then same-event conflicts."""
    current = copy.deepcopy(accumulated)
    for row in current.values():
        row["state"] = "accepted"
    for row in current.values():
        for target in row["supersedes"]:
            if target in current:
                current[target]["state"] = "superseded"
    groups = {}
    for row in current.values():
        if row["state"] == "superseded":
            continue
        group = tuple(row[k] for k in ("patient_id", "subject", "event_id", "kind", "concept", "event_time"))
        groups.setdefault(group, []).append(row)
    for rows in groups.values():
        if len({(r["value"], r["unit"], r["assertion"]) for r in rows}) > 1:
            for row in rows:
                row["state"] = "disputed"
    return current


def answer(chart, query):
    """Only the five operations and normalized timestamps in this saved case."""
    require(set(query) == {"name", "op", "kind", "concept", "subject"}, "Unsupported query shape")
    op = query["op"]
    require(op in {"all", "history", "latest", "earliest", "count"}, "Unsupported query")
    rows = [r for r in chart.values() if r["patient_id"] == "CR-02-0000"
            and all(r[k] == query[k] for k in ("kind", "concept", "subject"))
            and (op == "history" or r["state"] != "superseded")]
    if not rows:
        return {"status": "not_documented", "records": [], "value": None, "evidence": []}
    if op in {"latest", "earliest"}:
        time = (max if op == "latest" else min)(r["event_time"] for r in rows)
        rows = [r for r in rows if r["event_time"] == time]
    rows.sort(key=lambda r: (r["event_time"], r["event_id"], r["claim_id"]))
    disputed = any(r["state"] == "disputed" for r in rows)
    status = "conflicted" if disputed else "documented"
    if op != "count" and not disputed and any(r["assertion"] == "unknown" for r in rows):
        status = "explicitly_unknown"
    return {"status": status,
            "records": [{k: r[k] for k in ("claim_id", "event_id", "event_time", "value", "unit", "assertion", "state")} for r in rows],
            "value": len({r["event_id"] for r in rows}) if op == "count" and not disputed else None,
            "evidence": sorted({d for r in rows for d in r["evidence"]})}


def verify(data):
    require(data["model_id"] == "gpt-6-luna" and data["strategy"] == "extract_ledger", "Model/strategy")
    require(data["repeat"] == 0 and data["schedule"] == "chronological", "Repeat/schedule")
    require(data["episode_key"] == "r0-reconciliation_after_conflict-0000-chronological", "Episode identity")
    documents = data["source_documents"]
    require([d["doc_id"] for d in documents] == DOCS and all(d["patient_id"] == "CR-02-0000" for d in documents), "Six exact synthetic sources")
    require(all("SYNTHETIC RECORD" in d["text"] for d in documents), "Synthetic source labels")
    require("Recorded value: 138." in documents[0]["text"] and "value was 145" in documents[1]["text"], "Source values")
    require("Value: 140." in documents[2]["text"] and FIRST in documents[2]["text"] and SECOND in documents[2]["text"], "Explicit source correction")
    steps = data["checkpoints"]
    require(len(steps) == 6, "Six checkpoints required")
    final_expected = claims(steps[-1]["expected_chart"])
    require(set(final_expected) == {d + ":1" for d in DOCS}, "Expected final source membership")
    accumulated = {}
    for index, step in enumerate(steps, 1):
        require(step["step"] == index and step["new_document_ids"] == [DOCS[index - 1]], "Chronological step")
        require(sha(step["response_text"].encode()) == step["response_text_sha256"], "Response text hash")
        require(sha(step["prompt"].encode()) == step["prompt_text_sha256"], "Prompt text hash")
        encoded = json.dumps(step["prompt"], sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()
        require(sha(encoded) == step["prompt_protocol_sha256"], "Protocol prompt hash")
        payload = strict_json(step["prompt"].split("\nINPUT:\n", 1)[1])
        require(payload == {"patient_id": "CR-02-0000", "source_archive_in_received_order": documents[:index], "newly_delivered_documents": [documents[index - 1]]}, "Visible prompt documents")
        new = claims(strict_json(step["response_text"]))  # No fence removal or repair.
        require(set(new) <= {DOCS[index - 1] + ":1"}, "New-document extraction ownership")
        for cid, row in new.items():
            require(row["evidence"] == [DOCS[index - 1]] and row["patient_id"] == "CR-02-0000", "Response source ownership")
            require(cid not in accumulated, "Unexpected repeated extraction")
            accumulated[cid] = row
        observed = dispositions(accumulated)
        expected = dispositions({k: v for k, v in final_expected.items() if k.split(":")[0] in DOCS[:index]})
        require(observed == claims(step["observed_chart"]), "Saved observed state differs from responses")
        require(expected == claims(step["expected_chart"]), "Saved expected prefix inconsistent")
        require(FIRST not in observed and FIRST in expected, "138 must remain missing at every step")
        require(step["saved_score"]["exact_chart"] is False and observed != expected, "Saved checkpoint outcome")
        require(step["saved_score"]["expected_claims"] == index and step["saved_score"]["predicted_claims"] == index - 1, "Saved claim counts")
        if index == 1:
            require(new == {}, "First extraction must be empty")
        if index == 2:
            require(observed[SECOND]["value"] == "145" and observed[SECOND]["state"] == "accepted", "Observed 145 state")
            require(expected[FIRST]["state"] == expected[SECOND]["state"] == "disputed", "Expected conflict")
        if index >= 3:
            require(observed[CORRECTION]["value"] == "140" and observed[CORRECTION]["state"] == "accepted", "Accepted correction")
            require(expected[FIRST]["state"] == expected[SECOND]["state"] == observed[SECOND]["state"] == "superseded", "Superseded history")
            require(set(observed[CORRECTION]["supersedes"]) == {FIRST, SECOND}, "Retained correction links")
    correct = 0
    failed = []
    require(len(data["saved_queries"]) == 22, "22 saved queries required")
    require(len({q["question"]["name"] for q in data["saved_queries"]}) == 22, "Unique queries")
    for row in data["saved_queries"]:
        predicted, target = answer(observed, row["question"]), answer(expected, row["question"])
        require(predicted == row["predicted"] and target == row["expected"], "Saved query answers")
        require(row["correct"] is (predicted == target), "Saved query correctness")
        correct += predicted == target
        if predicted != target:
            failed.append(row["question"]["name"])
    require(correct == data["saved_final_query_correct"] == 21 and data["saved_final_query_total"] == 22, "Final query totals")
    require(failed == ["history:observation:lab:alpha:patient"], "Only history query fails")
    return {"status": "evidence_integrity_passed", "saved_model_exact_final_chart": False,
            "model_quality_interpretation": "Known incomplete record: evidence verification passed, model did not pass the exact-chart criterion.",
            "checkpoints": 6, "missing_138_checkpoints": 6,
            "final_queries_correct": 21, "final_queries_total": 22,
            "scope": "one saved synthetic episode; diagnostic, not full evaluator", "new_model_calls": 0}


def main():
    root = Path(__file__).resolve().parent
    manifest = strict_json((root / "manifest.json").read_text(encoding="utf-8"))
    require(set(manifest["files"]) == FILES, "Unexpected manifest membership")
    for name, metadata in manifest["files"].items():
        raw = (root / name).read_bytes()
        require(sha(raw) == metadata["sha256"] and len(raw) == metadata["bytes"], "Bundle member hash mismatch")
    raw = (root / "chartreplay-hidden-conflict.json").read_bytes()
    require(sha(raw) == DATA_SHA256, "Pinned diagnostic data changed")
    print(json.dumps(verify(strict_json(raw)), indent=2))


if __name__ == "__main__":
    try:
        main()
    except (ValueError, KeyError, TypeError, IndexError, OSError) as exc:
        raise SystemExit("FAILED: " + str(exc)) from None
