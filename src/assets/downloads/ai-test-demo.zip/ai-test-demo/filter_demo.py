"""Constructed test-quality demonstration. Python 3; no dependencies or LLM calls.

Run: python3 filter_demo.py

The exit code is zero only when every observed result matches the expected
matrix. Expected assertion failures are evidence produced by the demonstration.
"""

import io
import json
import sys
import unittest


ORDERS = [
    {"id": 1, "status": "paid"},
    {"id": 2, "status": "pending"},
]


def original(orders, statuses=None):
    statuses = statuses or []
    return [order for order in orders if order["status"] in statuses]


def plausible_patch(orders, statuses=None):
    if not statuses:
        return list(orders)
    return [order for order in orders if order["status"] in statuses]


def corrected_patch(orders, statuses=None):
    if statuses is None:
        return list(orders)
    return [order for order in orders if order["status"] in statuses]


def run_checks(implementation, include_empty):
    class FilterChecks(unittest.TestCase):
        def test_default_returns_all(self):
            self.assertEqual(implementation(ORDERS), ORDERS)

        def test_paid_filter(self):
            self.assertEqual(implementation(ORDERS, ["paid"]), [ORDERS[0]])

        def check_empty_returns_none(self):
            self.assertEqual(implementation(ORDERS, []), [])

    names = ["test_default_returns_all", "test_paid_filter"]
    if include_empty:
        names.append("check_empty_returns_none")
    suite = unittest.TestSuite(FilterChecks(name) for name in names)
    transcript = io.StringIO()
    result = unittest.TextTestRunner(stream=transcript, verbosity=2).run(suite)
    return {
        "passed": result.testsRun - len(result.failures) - len(result.errors),
        "failed": len(result.failures),
        "errors": len(result.errors),
        "failure_cases": [test.id().rsplit(".", 1)[-1] for test, _ in result.failures],
        "transcript": transcript.getvalue(),
    }


def main():
    expected = {
        "original": {"weak": (1, 1, 0), "contract": (2, 1, 0)},
        "plausible_patch": {"weak": (2, 0, 0), "contract": (2, 1, 0)},
        "corrected_patch": {"weak": (2, 0, 0), "contract": (3, 0, 0)},
    }
    implementations = [original, plausible_patch, corrected_patch]
    report = {}
    unexpected = []
    for implementation in implementations:
        report[implementation.__name__] = {}
        for name, include_empty in [("weak", False), ("contract", True)]:
            result = run_checks(implementation, include_empty)
            report[implementation.__name__][name] = result
            actual = tuple(result[key] for key in ("passed", "failed", "errors"))
            if actual != expected[implementation.__name__][name]:
                unexpected.append((implementation.__name__, name, actual))

    print("Constructed example; no coding agent or ExecCritic benchmark was run.\n")
    print(f"{'Implementation':<22} {'Two original checks':<24} {'With empty-list check'}")
    for name, suites in report.items():
        cells = [f"{r['passed']} passed, {r['failed']} failed" for r in suites.values()]
        print(f"{name:<22} {cells[0]:<24} {cells[1]}")

    print("\nKnown-wrong empty-filter expectation:")
    for implementation in implementations:
        accepts = implementation(ORDERS, []) == ORDERS
        print(f"  {implementation.__name__}: {'ACCEPTED' if accepts else 'REJECTED'}")
    if corrected_patch(ORDERS, []) == ORDERS:
        unexpected.append(("incorrect expectation accepted by corrected patch",))
    if plausible_patch(ORDERS, []) != ORDERS:
        unexpected.append(("incorrect expectation rejected by plausible patch",))

    if "--json" in sys.argv:
        print("\n" + json.dumps(report, indent=2))
    if unexpected:
        print(f"\nUNEXPECTED RESULTS: {unexpected}", file=sys.stderr)
        return 1
    print("\nAll outcomes matched the declared matrix. Expected failures are intentional.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
