#!/usr/bin/env python3
"""Run a transparent lexical retrieval probe. Python standard library only.

This program does not call or grade a language model.
"""

import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import re
import sys


K1 = 1.5
B = 0.75
TOKEN_PATTERN = r"[a-z0-9]+"
SYSTEM_PROMPT = (
    "You are helping with a software project. Answer the user request using relevant "
    "project memory when it applies. Memory can contain outdated decisions; an explicit "
    "newer decision supersedes an older one within its stated scope. Do not apply "
    "unrelated project constraints to unrelated requests. Explain your proposed behavior "
    "concisely. Do not claim you have executed code."
)


def tokenize(text):
    return re.findall(TOKEN_PATTERN, text.lower())


class BM25:
    def __init__(self, records):
        self.records = records
        self.terms = [Counter(tokenize(record["text"])) for record in records]
        self.lengths = [sum(terms.values()) for terms in self.terms]
        self.average_length = sum(self.lengths) / len(self.lengths)
        self.document_frequency = Counter()
        for terms in self.terms:
            self.document_frequency.update(terms.keys())

    def retrieve(self, query, top_k):
        query_terms = sorted(set(tokenize(query)))
        count = len(self.records)
        ranked = []
        for record, terms, length in zip(self.records, self.terms, self.lengths):
            score = 0.0
            for term in query_terms:
                frequency = terms.get(term, 0)
                if not frequency:
                    continue
                df = self.document_frequency[term]
                inverse_frequency = math.log(1 + (count - df + 0.5) / (df + 0.5))
                denominator = frequency + K1 * (
                    1 - B + B * length / self.average_length
                )
                score += inverse_frequency * frequency * (K1 + 1) / denominator
            if score > 0:
                ranked.append({"record_id": record["id"], "score": score})
        ranked.sort(key=lambda item: (-item["score"], item["record_id"]))
        return ranked[:top_k]


def positive_integer(value):
    number = int(value)
    if number < 1:
        raise argparse.ArgumentTypeError("top-k must be at least 1")
    return number


def validate(dataset):
    records = dataset["records"]
    cases = dataset["cases"]
    record_ids = [record["id"] for record in records]
    case_ids = [case["id"] for case in cases]
    updates = [case["supersession"]["id"] for case in cases]
    if not records or len(record_ids) != len(set(record_ids)):
        raise ValueError("records must be nonempty with unique IDs")
    if not cases or len(case_ids) != len(set(case_ids)):
        raise ValueError("cases must be nonempty with unique IDs")
    if len(updates) != len(set(updates)) or set(updates) & set(record_ids):
        raise ValueError("supersession IDs must be distinct from all other record IDs")
    for record in records:
        if not tokenize(record["text"]):
            raise ValueError("every memory record must have tokenizable text")
    for case in cases:
        if not re.fullmatch(r"[a-z0-9_]+", case["id"]):
            raise ValueError("case IDs must be safe lowercase file names")
        if case["target_record_id"] not in record_ids:
            raise ValueError("case target is missing from records")
        for field in (
            "direct_question", "indirect_task", "expected_behavior",
            "irrelevant_query", "irrelevant_expected_behavior",
        ):
            if not isinstance(case[field], str) or not case[field].strip():
                raise ValueError("case field must contain text: " + field)
        if not tokenize(case["supersession"]["text"]):
            raise ValueError("supersession memory must have tokenizable text")
        if not case["supersession"]["expected_behavior"].strip():
            raise ValueError("supersession expected behavior must contain text")


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def make_input(case_id, condition, query, context):
    # No reference answer, score, expected key, or target ID is put into messages.
    memory_text = "\n\n".join(record["text"] for record in context)
    return {
        "schema_version": 1,
        "input_id": case_id + "__" + condition,
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": "Project memory:\n" + (memory_text or "(none)") + "\n\nRequest:\n" + query},
        ],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", type=Path, default=Path(__file__).with_name("cases.json"))
    parser.add_argument("--top-k", type=positive_integer, default=3)
    parser.add_argument("--output-dir", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    raw = args.dataset.read_bytes()
    dataset = json.loads(raw)
    validate(dataset)
    output = args.output_dir
    output.mkdir(parents=True, exist_ok=True)
    input_dir = output / "inputs"
    input_dir.mkdir(parents=True, exist_ok=True)
    records = dataset["records"]
    by_id = {record["id"]: record for record in records}
    retriever = BM25(records)
    case_results = []
    input_manifest = []
    rubrics = []
    for case in dataset["cases"]:
        target = case["target_record_id"]
        found = {
            "direct": retriever.retrieve(case["direct_question"], args.top_k),
            "implicit": retriever.retrieve(case["indirect_task"], args.top_k),
            "irrelevant": retriever.retrieve(case["irrelevant_query"], args.top_k),
        }
        update = {"id": case["supersession"]["id"], "text": case["supersession"]["text"]}
        updated_records = records + [update]
        updated_by_id = dict(by_id, **{update["id"]: update})
        found["supersession_retrieved"] = BM25(updated_records).retrieve(case["indirect_task"], args.top_k)
        details = {}
        for condition, ranking in found.items():
            ids = [item["record_id"] for item in ranking]
            details[condition] = {
                "ranking": ranking,
                "target_fact_retrieved": target in ids,
            }
            if condition == "supersession_retrieved":
                details[condition]["newer_fact_retrieved"] = update["id"] in ids
        contexts = {
            "direct": [by_id[item["record_id"]] for item in found["direct"]],
            "implicit": [by_id[item["record_id"]] for item in found["implicit"]],
            # Deliberately fixed minimal oracle context, not BM25 retrieval.
            "explicit": [by_id[target]],
            "irrelevant": [by_id[item["record_id"]] for item in found["irrelevant"]],
            "supersession_retrieved": [updated_by_id[item["record_id"]] for item in found["supersession_retrieved"]],
            # Deliver both decisions in chronological order for a behavioral control.
            "supersession_explicit": [by_id[target], update],
        }
        for condition, context in contexts.items():
            query = (
                case["direct_question"] if condition == "direct" else
                case["irrelevant_query"] if condition == "irrelevant" else
                case["indirect_task"]
            )
            filename = case["id"] + "__" + condition + ".json"
            write_json(input_dir / filename, make_input(case["id"], condition, query, context))
            input_manifest.append({
                "input_id": case["id"] + "__" + condition,
                "file": "inputs/" + filename,
                "condition": condition,
                "delivered_record_ids": [record["id"] for record in context],
            })
        case_results.append({"case_id": case["id"], "target_record_id": target, "retrieval": details})
        rubrics.append({
            "case_id": case["id"],
            "direct_reference_fact": by_id[target]["text"],
            "implicit_and_explicit_expected_behavior": case["expected_behavior"],
            "irrelevant_expected_behavior": case["irrelevant_expected_behavior"],
            "supersession_expected_behavior": case["supersession"]["expected_behavior"],
            "agent_response": None,
            "behavioral_grade": None,
        })
    count = len(case_results)
    summary = {}
    for condition in ("direct", "implicit", "irrelevant"):
        summary[condition] = {
            "target_fact_retrieved_count": sum(item["retrieval"][condition]["target_fact_retrieved"] for item in case_results),
            "case_count": count,
        }
    summary["supersession_retrieved"] = {
        "old_target_fact_retrieved_count": sum(item["retrieval"]["supersession_retrieved"]["target_fact_retrieved"] for item in case_results),
        "newer_fact_retrieved_count": sum(item["retrieval"]["supersession_retrieved"]["newer_fact_retrieved"] for item in case_results),
        "case_count": count,
    }
    report = {
        "schema_version": 1,
        "dataset_sha256": hashlib.sha256(raw).hexdigest(),
        "retriever": {
            "name": "BM25 lexical illustration", "top_k": args.top_k, "k1": K1, "b": B,
            "token_pattern": TOKEN_PATTERN, "query_terms": "unique", "stopwords": "none",
            "stemming": "none", "zero_scores": "excluded", "ties": "ascending record_id",
        },
        "base_corpus_record_count": len(records),
        "corpus_for_each_supersession_case": "base corpus plus only that case's newer decision",
        "summary": summary,
        "delivery_controls": {
            "explicit": {"target_fact_delivered_count": count, "case_count": count, "method": "inject target fact alone, no retrieval"},
            "supersession_explicit": {"old_and_new_fact_delivered_count": count, "case_count": count, "method": "inject old fact then newer decision, no retrieval"},
        },
        "external_agent_evaluation": {"run": False, "response_count": 0, "behavioral_scores": None},
        "interpretation": [
            "Retrieval hits are context-delivery measurements, not correctness or fact-use measurements.",
            "Irrelevant target hits indicate target exposure on an unrelated query; they do not establish behavioral over-application.",
            "Supersession retrieval does not establish whether an agent follows the newer decision.",
            "Explicit controls have different context from retrieved conditions and are not a controlled causal comparison.",
            "Handwritten vocabulary-sensitive toy fixture; not representative, not SOTA memory, not an InMind replication.",
        ],
        "cases": case_results,
    }
    write_json(output / "results.json", report)
    write_json(output / "input-manifest.json", input_manifest)
    write_json(output / "behavioral-rubrics.json", {"evaluation_run": False, "cases": rubrics})
    print(json.dumps({"dataset_sha256": report["dataset_sha256"], "summary": summary, "isolated_inputs_written": len(input_manifest), "external_agent_evaluation_run": False}, indent=2))
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (ValueError, KeyError, OSError) as error:
        print("error: " + str(error), file=sys.stderr)
        sys.exit(1)
