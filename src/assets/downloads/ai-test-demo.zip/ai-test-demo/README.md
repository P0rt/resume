# A green test can miss the requirement

A self-contained, deliberately constructed companion to **AI-Generated Tests Can Make Coding Agents Worse. Here's How to Check Yours**.

This is an authored Python fixture, not an observed coding-agent incident and not an ExecCritic replication. It makes no LLM or network calls.

## Run

Python 3 is the only requirement:

```sh
python3 filter_demo.py
```

Add `--json` to print the individual test transcripts.

## Contract

- An omitted filter or `None` returns all orders.
- An empty status list returns no orders.
- A nonempty status list returns orders whose status belongs to that list.

## Expected observations

| Implementation | Default and paid checks | Those checks plus empty-list check |
|---|---|---|
| Original: treats `None` as an empty selection | 1 passes, 1 fails | 2 pass, 1 fails |
| Plausible patch: treats every falsey filter as unrestricted | 2 pass | 2 pass, 1 fails |
| Corrected patch: handles `None` explicitly | 2 pass | 3 pass |

The program checks these outcomes and exits nonzero if the matrix changes unexpectedly. The deliberately failing cases are captured and reported; they are not hidden as successful test results.

The final lines also check an explicitly wrong expectation: that an empty filter returns every order. That expectation accepts the plausible patch and rejects the correct one.

The example omits application concerns such as schema validation, pagination, persistence, and authorization. The three checks illustrate this declared filter contract only.

## Research context

Leitian Tao and colleagues, [ExecCritic, v1, September 8, 2026](https://arxiv.org/html/2609.09133v1), supplies the separate benchmark results discussed in the article. This demo does not reproduce or measure those results.
