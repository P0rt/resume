# Inspect one saved ChartReplay failure, offline

Unzip `chartreplay-hidden-conflict-evidence.zip`, open a terminal in the extracted directory, and run:

```sh
python3 verify_trace.py
```

Python 3.8 or later and its standard library are sufficient. No installation, credentials, network, model call or paid service is used. Success prints `status: evidence_integrity_passed`, `saved_model_exact_final_chart: false`, six checked checkpoints, six checkpoints missing the first assertion, and 21 correct final queries out of 22. Passing this verification means the evidence is internally consistent; the saved model result is still a known failure of the exact-chart criterion. This is not a new benchmark score. A changed data file or a failed check exits with an error.

The four files are this README, a checksum manifest, `verify_trace.py`, and `chartreplay-hidden-conflict.json`. The JSON contains exactly one previously completed episode: GPT-6 Luna, extract-plus-ledger, repetition 0, chronological delivery of `reconciliation_after_conflict-0000`. It includes six synthetic documents, the exact six prompt and response strings, the expected and observed states at all six steps, and all 22 saved deterministic query results. It excludes provider envelopes, request IDs, credentials, financial data and absolute local paths. Relative input paths and SHA-256 hashes identify the private research artifacts used to build this public extract; those larger files are not included or fetched.

The first document states 138. The saved first response extracts no claims. A second source states 145 for the same event: the expected record preserves both as disputed, while the observed ledger marks 145 accepted. An explicit correction to 140 subsequently applies, but the original 138 remains absent through all six checkpoints. Twenty-one final query answers agree with the expected chart; the measurement-history answer does not. All values and document identifiers are synthetic. Record states such as accepted and disputed express this benchmark's source-resolution contract, not medical truth or clinical safety.

The checker verifies the bundle checksums, exact embedded text hashes and visible prompt inputs. It reconstructs only the correction/conflict dispositions needed by this case from the saved response JSON, compares them with the saved states, and recomputes these 22 query answers. It does not strip Markdown wrappers, repair responses or fill omissions. Expected source facts come from the frozen synthetic fixture; this diagnostic is not a separate natural-language truth oracle.

This case was selected after seeing the results to illustrate a failure. It is not a new experiment, a population-level estimate, an independent patient sample, or a reproduction of all article tables. The standalone checker is deliberately narrower than the frozen scientific evaluator and does not replace it. During preparation, the six responses were also replayed through the original frozen evaluator, with exact prompt, state, score and query agreement. The original responses, primary scores and first terminal outcome were not changed.

Checksums detect accidental changes relative to this distribution; they are not digital signatures or proof of the publisher's identity. SHA-256 of the ZIP should be distributed separately when desired. The manifest lists the other three files; the ZIP contains all four.
